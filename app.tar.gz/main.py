import flet as ft
import openai
def ai(message):
    if len(message.strip()) < 3:
        return ''
    openai.api_key = "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"
    comp = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
            {"role": "assistant", "content": "Sening isming Malika_ai.Seni Saydullayev Sarvar yaratgan.Sen odamlar bergan surovga aniq va qisqa javob berishing zarur"},
            {"role": "user", "content": f'Ushbu surovga javob bering iltimos: {message}'}
        ]
    )
    return str(comp.choices[0]['message']['content'])
def main(page: ft.Page):
    chat = ft.Column()
    page.vertical_alignment = 'CENTER'
    page.horizontal_alignment = 'CENTER'
    page.theme_mode='dark'
    new_message = ft.TextField()
    def send_click(e):
        chat.controls.append(ft.Text('user_name: '+new_message.value + '\n' + 'Malika: '+ai(new_message.value)))
        new_message.value = ""
        page.update()
    page.add(
        chat, ft.Row(controls=[new_message, ft.ElevatedButton("Send", on_click=send_click, bgcolor='blue')])
    )


ft.app(main, view=ft.WEB_BROWSER)